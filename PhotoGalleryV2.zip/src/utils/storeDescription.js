const STORAGE_KEY = "photoDescription";

export const getStoredDescription = () => {
  try {
    const descriptionData = localStorage.getItem(STORAGE_KEY);
    return descriptionData ? JSON.parse(descriptionData) : {};
  } catch (error) {
    console.error("couldn't retreieve the photo description", error);
  }
};

export const saveDescription = (id,description) => {
  try {
    const descriptions = getStoredDescription();
    descriptions[id] = description;
    const data = JSON.stringify(descriptions);
    localStorage.setItem(STORAGE_KEY, data);
  } catch (error) {
    console.error("Error getting the description");
    return {};
  }
};


