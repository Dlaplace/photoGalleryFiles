import axios from 'axios';

const API_url = "https://jsonplaceholder.typicode.com/photos";

export const getPhotos = async()=>{
  try {
    const response  = await axios.get(API_url);
    return response.data.slice(0,25);
  } catch (error ){
    console.error('Error getting the photos', error);
    return[]
  }
}
