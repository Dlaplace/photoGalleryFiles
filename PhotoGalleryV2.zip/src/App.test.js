import React from 'react';
import { render, screen } from '@testing-library/react';
import PhotoGallery from './App';

jest.mock('./components/PhotoGrid/PhotoGrid', () => (() => <div>Mocked PhotoGrid</div>));


describe('photoGallery', ()=>{

  test('it renders the gallery title', ()=>{
    render(<PhotoGallery></PhotoGallery>);
    const title = screen.getByText(/gallery/i);
    expect(title).toBeInTheDocument();
  })

  test('it renders the photo grid on the photo gallery',()=>{
    render(<PhotoGallery />);
    const photoGridElement = screen.getByText(/mocked photogrid/i);
    expect(photoGridElement).toBeInTheDocument();
  })
})