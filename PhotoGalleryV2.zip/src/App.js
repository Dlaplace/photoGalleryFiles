import React from "react";
import PhotoGrid from "./components/PhotoGrid/PhotoGrid.jsx";
import "./App.css"

function PhotoGallery(){
  return (
    <div className="container">
      <h1>Gallery</h1>
      <PhotoGrid/>
    </div>
  )
}

export default PhotoGallery;