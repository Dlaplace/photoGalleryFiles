/* eslint-disable testing-library/no-wait-for-multiple-assertions */
import React from "react";
import PhotoDetail from "./PhotoDetail";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";

const mockedPhoto = {
  id: 2,
  title: "Photo 2",
  thumbnailUrl: "url2",
  url: "url2",
  description: "photodescription",
};

const mockedOnSaveDescription = jest.fn();

describe('PhotoDetail',()=>{
  test('it renders the image',async ()=>{
    render(<PhotoDetail photo={mockedPhoto} onSaveDescription={mockedOnSaveDescription}/>);
    expect(screen.getByText(/Photo 2/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /change description/i })).toBeInTheDocument();
    expect(screen.getByText(/photodescription/i)).toBeInTheDocument();
  })

  test('shows placeholder text when description is empty', () => {
    const photoWithoutDescription = { ...mockedPhoto, description: '' };
    render(<PhotoDetail photo={photoWithoutDescription} onSaveDescription={mockedOnSaveDescription} />);

    expect(screen.getByText(/provide me a description, please!/i)).toBeInTheDocument();
  });

  test('shows loader initially and hides after image loads', async () => {
    render(<PhotoDetail photo={mockedPhoto} onSaveDescription={mockedOnSaveDescription} />);

    expect(screen.getByRole(/status/i)).toBeInTheDocument();

    const img = screen.getByAltText(/Photo 2/i);
    fireEvent.load(img);

    await waitFor(() => {
      expect(screen.queryByText(/loading/i)).not.toBeInTheDocument();
      expect(img).toBeVisible();
    });
  });

  test.todo('test on editing image on toggle edit');
  test.todo('test on saving imagedescription');
})