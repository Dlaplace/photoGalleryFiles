import React, { useEffect, useState } from "react";
import "./PhotoDetail.css";
import Loader from "../Loader/Loader";

const PhotoDetail = ({ photo, onSaveDescription }) => {
  const [description, setDescription] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [imageLoading, setImageLoading] = useState(true); 

  useEffect(() => {
    setDescription(photo.description);
  }, [photo]);

  const handleSave = () => {
    onSaveDescription(photo.id, description);
    handleToggleEdit();
  };

  const handleToggleEdit = () => {
    setIsEditing(!isEditing);
  };

  const handleImageLoad = () => {
    setImageLoading(false);
  };

  return (
    <div className="photo-detail-container">
      <div className="photo-detail">
        {imageLoading && <div role="status"><Loader/></div>}
        <img
          src={photo.url}
          alt={photo.title}
          className="full-image"
          onLoad={handleImageLoad} 
          style={{ display: imageLoading ? "none" : "block" }} 
        />
        <h3>{photo.title}</h3>
        <div className="description-container mt-2">
          {!isEditing ? (
            <div className="description-section">
              <p className="description-text">{description || "Provide me a description, please!"}</p>
              <button className="button" onClick={handleToggleEdit}>
                Change Description
              </button>
            </div>
          ) : (
            <div className="edit-section">
              <input
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add description here..."
              />
              <button className="button" onClick={handleSave}>
                Save Description
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PhotoDetail;