import React, { useEffect, useState } from "react";
import { getPhotos } from "../../utils/api";
import Modal from "../Modal/Modal";
import Loader from "../Loader/Loader";
import PhotoDetail from "../PhotoDetail/PhotoDetail";
import "./PhotoGrid.css";
import {
  saveDescription,
  getStoredDescription,
} from "../../utils/storeDescription";

const PhotoGrid = () => {   
  const [photos, setPhotos] = useState([]);
  const [activePhoto, setActivePhoto] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    const fetchPhotos = async () => {
      try {
        const fetchedPhotos = await getPhotos();
        const photoDescriptions = getStoredDescription();
        const photosWithDescriptions = fetchedPhotos.map((photo) => ({
          ...photo,
          description: photoDescriptions[photo.id] || "",
        }));
        setPhotos(photosWithDescriptions);
      } catch (error) {
        setError("couldn't fetch photos");
      } finally {
        setLoading(false);
      }
    };

    fetchPhotos();
  }, []);

  const onClickPhoto = (photo) => {
    setActivePhoto(photo);
  };

  const handleCloseModal = () => {
    setActivePhoto(null);
  };

  const handleSaveDescription = (id, description) => {
    saveDescription(id, description);
    setPhotos(
      photos.map((photo) =>
        photo.id === id ? { ...photo, description } : photo
      )
    );
  };

  if (loading) return <div role="status"><Loader/></div>;
  if (error) return <div>{error}</div>;
  return (
    <div className="container-fluid">
      <div className="row no-gutters">
        {photos.map((photo) => (
          <div key={photo.id} className=" col-sm-6 col-md-4 col-lg-3 col-xl-2-4  p-2">
            <img
              src={photo.thumbnailUrl}
              alt={photo.title}
              className="img-fluid rounded photo-thumbnail"
              onClick={() => onClickPhoto(photo)}
            />
          </div>
        ))}
      </div>
      <Modal isOpen={!!activePhoto} onClose={handleCloseModal}>
        {activePhoto && (
          <PhotoDetail
            photo={activePhoto}
            onSaveDescription={handleSaveDescription}
          />
        )}
      </Modal>
    </div>
  );
};

export default PhotoGrid;
