/* eslint-disable testing-library/no-wait-for-side-effects */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import PhotoGrid from "./PhotoGrid";
import { getPhotos } from "../../utils/api";
import { getStoredDescription } from "../../utils/storeDescription";


jest.mock('../../utils/api');
jest.mock('../../utils/storeDescription');

const mockPhotos = [
  { id: 1, title: 'Photo 1', thumbnailUrl: 'url1', url: 'url1' },
  { id: 2, title: 'Photo 2', thumbnailUrl: 'url2', url: 'url2' },
]

describe('photogrid',()=>{
  beforeEach(()=>{
    getPhotos.mockResolvedValue(mockPhotos);
    getStoredDescription.mockResolvedValue({});
  })

  test('it renders loading state initially', () => {
    render(<PhotoGrid />);
    const loadingComponent = screen.getByRole('status');
    expect(loadingComponent).toBeInTheDocument();
  });
  
  test('it loads the photos', async()=>{
    render(<PhotoGrid />);
    await waitFor(()=>{
      expect(screen.getAllByRole('img')).toHaveLength(2)
    })
  })
  
  test('it open the modal when its clicked', async()=>{
    render(<PhotoGrid />);
    await waitFor(()=>{
      const imageList = screen.getAllByRole('img');
      fireEvent.click(imageList[0]);
      expect(screen.getByText(/Photo 1/i)).toBeInTheDocument();
    })
  })
  
  test('it handles an error case on error loading images',async ()=>{
    getPhotos.mockRejectedValue(new Error('Error'))
    render(<PhotoGrid />);
    await waitFor(()=>{
      expect(screen.getByText(/couldn't fetch photos/i)).toBeInTheDocument();
    })
  })



})