# Photo Gallery

This project is a photo gallery! Was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Details

The project includes a 5x5 grid of images in desktop mode, responsive, and a modal to see the full image and title with the option to add a description and edit it.

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Tests are pending...
